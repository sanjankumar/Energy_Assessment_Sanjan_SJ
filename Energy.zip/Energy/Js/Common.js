myAngApp.controller('Controller-common', function ($scope, $http, $sce, $timeout, $location, $rootScope) {

    $scope.initFunc1 = function () {
        $scope.loaded = false;
        $timeout( function(){ $scope.loaded = true; }, 500);
    }
    
    $scope.initFunc1();
});