var myAngApp = angular.module('SharePointAngApp', ['ngSanitize']);

// Initializing Page Loader to false
myAngApp.run(function($rootScope) {     
    $rootScope.loaded = false;
}); 


